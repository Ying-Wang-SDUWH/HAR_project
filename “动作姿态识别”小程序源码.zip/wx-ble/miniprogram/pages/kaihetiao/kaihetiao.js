const app = getApp()
//获取数据库引用
const db = wx.cloud.database();
const accelerometerDB = db.collection('movement3')
Page({
  data: {
    capsuleInfo: app.globalData.capsuleInfo,
    value: 0,
    displayValue:0,
    accelerometerX: null,
    accelerometerY: null,
    accelerometerZ: null,
    accXs: [],
    accYs: [],
    accZs: [],
    gyrXs: [],
    gyrYs: [],
    gyrZs: [],
    timeSs: [],
    startTime: 0,
  },



  start: function (e) {
    let accXs = [];
    let accYs = [];
    let accZs = [];
    let gyrXs = [];
    let gyrYs = [];
    let gyrZs = [];
    let timeSs = [];
    this.setData({ startTime: new Date().getTime() })
    let _this = this;
    _this.setData({ isReading: true })
    setTimeout(function () {
      console.log("stop")
      wx.offAccelerometerChange()
      wx.stopAccelerometer({})
      wx.offGyroscopeChange()
      wx.stopGyroscope({})
      _this.setData({isReading:false})
      _this.setData({ accXs: accXs, accYs: accYs, accZs: accZs, gyrXs: gyrXs, gyrYs: gyrYs, gyrZs: gyrZs, timeSs: timeSs })
    }, 10000)
    wx.startGyroscope({
      interval: 'ui',
      success() {
        console.log("调用成功");
        wx.onGyroscopeChange(function (res1) {
          gyrXs.push(res1.x)
          gyrYs.push(res1.y)
          gyrZs.push(res1.z)
        })
    },
  })
    wx.startAccelerometer({
      interval: 'ui',
      success() {
        console.log("调用成功");
        wx.onAccelerometerChange(function (res) {
          let mid_time = new Date().getTime();
          console.log("mid-time: ", mid_time, "startTime: ", _this.data.startTime)
          let timeStep = (mid_time - _this.data.startTime) / 1000
          _this.setData({ value: parseInt(timeStep * 10), displayValue: parseInt(timeStep) });
            accXs.push(res.x)
            accYs.push(res.y)
            accZs.push(res.z)
            timeSs.push(mid_time)
        })
      }
    })
},

stop: function () {
    let _this = this
    this.setData({ isReading: false })
    wx.stopAccelerometer({
      success: res => {
        console.log("停止读取")
        _this.setData({ accelerometerX: null, accelerometerY: null, accelerometerZ: null, activity: null })
      }
    })
  },


  num: function (e) {
    let _this = this
    console.log("save...")
    var num=e.detail.value.num;
    console.log(num)
    var system=wx.getStorageSync('system')
    wx.showLoading({title: '加载中...',})
    accelerometerDB.add({
      data: { accXs: _this.data.accXs, accYs: _this.data.accYs, accZs: _this.data.accZs, gyrXs: _this.data.gyrXs, gyrYs: _this.data.gyrYs, gyrZs: _this.data.gyrZs, system:system , timeSs: _this.data.timeSs}
    })
      .then(res => {
        console.log("保存成功");
        wx.hideLoading()
        wx.showToast({
          title: '保存成功',
        })
      })
      .catch(res => { console.log("保存失败") })
  },
})