// pages/first/first.js
Page({
  data: {
    array1: ['150以下', '151-155', '156-160', '161-165', '166-170', '171-175', '176-180', '181-185','186-190','190以上'],
    objectArray1: [
      {
        id: 0,
        name: '150以下'
      },
      {
        id: 1,
        name: '151-155'
      },
      {
        id: 2,
        name: '156-160'
      },
      {
        id: 3,
        name: '161-165'
      },
      {
        id: 4,
        name: '166-170'
      },
      {
        id: 5,
        name: '171-175'
      },
      {
        id: 6,
        name: '176-180'
      },
      {
        id: 7,
        name: '181-185'
      },
      {
        id: 8,
        name: '186-190'
      },
      {
        id: 9,
        name: '190以上'
      }
    ],
    index1: 0,
    array2: ['15以下', '16-25', '26-35', '36-45', '46-55', '55以上'],
    objectArray2: [
      {
        id: 0,
        name: '15以下'
      },
      {
        id: 1,
        name: '16-25'
      },
      {
        id: 2,
        name: '26-35'
      },
      {
        id: 3,
        name: '36-45'
      },
      {
        id: 4,
        name: '46-55'
      },
      {
        id: 5,
        name: '55以上'
      }

    ],
    index2: 0,
    array3: ['男', '女'],
    objectArray3: [
      {
        id: 0,
        name: '男'
      },
      {
        id: 1,
        name: '女'
      }

    ],
    index3: 0,
    array4: ['ios系统', '安卓系统'],
    objectArray4: [
      {
        id: 0,
        name: 'ios系统'
      },
      {
        id: 1,
        name: '安卓系统'
      }

    ],
    index4: 0,
    elements: [{
      title: '徒手侧平举',
      name: '1',
      color: 'orange',
      pinyin:'hezhangtiao',
      shifan:'hezhang'
    },
    {
      title: '前后交叉小跑',
      name: '2',
      color: 'my3',
      pinyin:'jiaochapao',
      shifan:'jiaocha'
    },
    {
      title: '开合跳',
      name: '3',
      color: 'my2',
      pinyin:'kaihetiao',
      shifan:'kaihe'
    },
    {
      title: '半蹲',
      name: '4',
      color: 'my1',
      pinyin:'bandun',
      shifan:'ban'
    }]
  },

  tocollect:function(){
    wx.navigateTo({
      url: '../collect/collect',
    })
  },

  torecognize:function(){
    wx.navigateTo({
      url: '../recognize/recognize',
    })
  },

  bindPickerChange1: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      index1: e.detail.value
    })
    wx.setStorageSync('height', e.detail.value)
  },
    bindPickerChange2: function (e) {
      console.log('picker发送选择改变，携带值为', e.detail.value)
      this.setData({
        index2: e.detail.value
      })
      wx.setStorageSync('age', e.detail.value)
  },
  bindPickerChange3: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      index3: e.detail.value
    })
    wx.setStorageSync('sex', e.detail.value)
  },
  bindPickerChange4: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      index4: e.detail.value
    })
    wx.setStorageSync('phone', e.detail.value)
  },
})