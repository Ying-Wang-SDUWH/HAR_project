// pages/cepingju/cepingju.js
const app = getApp()
//获取数据库引用
const db = wx.cloud.database();
const accelerometerDB = db.collection('movement2')
let accXs = [];
let accYs = [];
let accZs = [];
let gyrXs = [];
let gyrYs = [];
let gyrZs = [];
let timeSs = [];
Page({

  /**
   * 页面的初始数据
   */
  data: {
    capsuleInfo: app.globalData.capsuleInfo,
    value: 0,
    displayValue:0,
    accelerometerX: null,
    accelerometerY: null,
    accelerometerZ: null,
    accXs: [],
    accYs: [],
    accZs: [],
    gyrXs: [],
    gyrYs: [],
    gyrZs: [],
    timeSs: [],
    startTime: 0,
  },

  startAccelerometer: function (e) {
    this.setData({ startTime: new Date().getTime() })
    let _this = this;
    _this.setData({ isReading: true })
    setTimeout(function () {
      console.log("stop")
      wx.offAccelerometerChange()
      wx.offGyroscopeChange()
      wx.stopAccelerometer({})
      wx.stopGyroscope({})
      _this.setData({isReading:false})
      _this.setData({ accXs: accXs, accYs: accYs, accZs: accZs, gyrXs: gyrXs, gyrYs: gyrYs, gyrZs: gyrZs, timeSs: timeSs })
    }, 10000)
    wx.startGyroscope({
      interval: 'ui',
      success() {
        console.log("调用成功");
        wx.onGyroscopeChange(function (res1) {
          gyrXs.push(res1.x)
          gyrYs.push(res1.y)
          gyrZs.push(res1.z)
          _this.setData({
            gyroscopeX: parseFloat(res1.x.toFixed(5)),
            gyroscopeY: parseFloat(res1.y.toFixed(5)),
            gyroscopeZ: parseFloat(res1.z.toFixed(5))
          })
        })
    },
  })
    wx.startAccelerometer({
      interval: 'ui',
      success() {
        console.log("调用成功");
        wx.onAccelerometerChange(function (res) {
          let mid_time = new Date().getTime();
          console.log("mid-time: ", mid_time, "startTime: ", _this.data.startTime)
          let timeStep = (mid_time - _this.data.startTime) / 1000
          _this.setData({ value: parseInt(timeStep * 10), displayValue: parseInt(timeStep) });
            accXs.push(res.x)
            accYs.push(res.y)
            accZs.push(res.z)
            timeSs.push(mid_time)
            _this.setData({
              accelerometerX: parseFloat(res.x.toFixed(5)),
              accelerometerY: parseFloat(res.y.toFixed(5)),
              accelerometerZ: parseFloat(res.z.toFixed(5))
            })
        })
      }
    })
  
},

stopAccelerometer: function () {
    let _this = this
    this.setData({ isReading: false })
    wx.stopAccelerometer({
      success: res => {
        console.log("停止读取")
        _this.setData({ accelerometerX: null, accelerometerY: null, accelerometerZ: null, activity: null })
      }
    })
  },


  num: function (e) {
    console.log("save...")
    var num=e.detail.value.num;
    console.log(num)
    var system=wx.getStorageSync('system')
    wx.showLoading({title: '加载中...',})
    accelerometerDB.add({
      data: { accXs: accXs, accYs: accYs, accZs: accZs, gyrXs: gyrXs, gyrYs: gyrYs, gyrZs: gyrZs, system:system , timeSs: timeSs}
    })
      .then(res => {
        console.log("保存成功");
        wx.hideLoading()
        wx.showToast({
          title: '保存成功',
        })
      })
      .catch(res => { console.log("保存失败") })
  },

  stopAccelerometer: function () {
    let _this = this
    this.setData({ isReading: false })
    wx.stopAccelerometer({
      success: res => {
        console.log("停止读取")
        _this.setData({ accelerometerX: null, accelerometerY: null, accelerometerZ: null, activity: null })
      }
    })
  },

  onLoad(){
    //添加音效
    // const innerAudioContext = wx.createInnerAudioContext()
    // innerAudioContext.autoplay = true  // 是否自动开始播放，默认为 false
    // innerAudioContext.loop =false  // 是否循环播放，默认为 false
    // wx.setInnerAudioOption({ // ios在静音状态下能够正常播放音效
    //   obeyMuteSwitch: false,   // 是否遵循系统静音开关，默认为 true。当此参数为 false 时，即使用户打开了静音开关，也能继续发出声音。
    //   success: function(e) {
    //     console.log(e)
    //     console.log('play success')
    //   },
    //   fail: function(e) {
    //     console.log(e)
    //     console.log('play fail')
    //   }
    // })
    // innerAudioContext.src = 'cloud://newenv-llmat.6e65-newenv-llmat-1301109829/The Stanley Parable-倒计时_03(Cou_爱给网_aigei_com.mp3';  // 音频资源的地址
    // innerAudioContext.onPlay(() => {  // 监听音频播放事件
    //   console.log('开始播放')
    // })
    // innerAudioContext.onError((res) => { // 监听音频播放错误事件
    //   console.log(res.errMsg)
    //   console.log('123')
    // })
  }
})