var action = ['徒手侧平举', '前后交叉小跑', '开合跳', '深蹲']
var timer
var submit
wx.setInnerAudioOption({ // ios在静音状态下能够正常播放音效
  obeyMuteSwitch: false,   // 当此参数为 false 时，即使用户打开了静音开关，也能继续发出声音。
  success: function(e) {
    console.log('play success')
  },
  fail: function(e) {
    console.log('play fail')
  }
})
const innerAudioContext1 = wx.createInnerAudioContext()
innerAudioContext1.src='cloud://newenv-llmat.6e65-newenv-llmat-1301109829/开始.mp3'; 
const innerAudioContext2 = wx.createInnerAudioContext()
innerAudioContext2.src='cloud://newenv-llmat.6e65-newenv-llmat-1301109829/徒手侧平举.mp3';  
const innerAudioContext3 = wx.createInnerAudioContext()
innerAudioContext3.src='cloud://newenv-llmat.6e65-newenv-llmat-1301109829/前后交叉小跑.mp3'; 
const innerAudioContext4 = wx.createInnerAudioContext()
innerAudioContext4.src='cloud://newenv-llmat.6e65-newenv-llmat-1301109829/开合跳.mp3'; 
const innerAudioContext5 = wx.createInnerAudioContext()
innerAudioContext5.src='cloud://newenv-llmat.6e65-newenv-llmat-1301109829/深蹲.mp3';  
const innerAudioContext6 = wx.createInnerAudioContext()
innerAudioContext6.src='cloud://newenv-llmat.6e65-newenv-llmat-1301109829/结束.mp3'; 

const bobao = [innerAudioContext2, innerAudioContext3, innerAudioContext4, innerAudioContext5]
Page({
  data: {
    m:0,
    literal:'开始检测',
    result : [],
    current_ation:'暂无',
    all_data:{}
  },

  test:function(){
    let accXs = [];             //存储临时数据
    let accYs = [];
    let accZs = [];
    let gyrXs = [];
    let gyrYs = [];
    let gyrZs = [];
    this.data.m = 0
    var _this = this
    this.setData({ startTime: new Date().getTime(), isReading: true, displayValue : 0, value:0})
    setTimeout(function () {
      console.log("stop")
      wx.offAccelerometerChange()
      wx.offGyroscopeChange()
      wx.stopAccelerometer({})
      wx.stopGyroscope({})
      _this.setData({isReading:false, literal :'显示详细信息'})
      clearInterval(timer)
      clearInterval(submit)
      innerAudioContext6.play()
    }, 30500)
    timer = setInterval(_this.timer, 2000)
    submit = setInterval(_this.submit, 3000)
    _this.setData({ startTime: new Date().getTime()})
    wx.startAccelerometer({
      interval: 'ui',
      success: res => { 
        console.log("调用成功");
        wx.onAccelerometerChange(function (res) {
          let mid_time = new Date().getTime();
          console.log("mid-time: ", mid_time, "startTime: ", _this.data.startTime)
          let timeStep = (mid_time - _this.data.startTime) / 1000
          _this.setData({ value: parseInt(timeStep * 3.33), displayValue: parseInt(timeStep)});
          accXs.push(res.x)
          accYs.push(res.y)
          accZs.push(res.z)
          _this.setData({ accXs: accXs, accYs: accYs, accZs: accZs})
        })
       },
      fail: res => { console.log(res) }
    })
    wx.startGyroscope({
      interval: 'ui',
      success: res => {
        console.log("调用成功");
        wx.onGyroscopeChange(function (res1) {
          gyrXs.push(res1.x)
          gyrYs.push(res1.y)
          gyrZs.push(res1.z)
          _this.setData({ gyrXs: gyrXs, gyrYs: gyrYs, gyrZs: gyrZs})
        })
      }
    })
  },

  timer(){
    if((this.data.result[this.data.result.length-1] != this.data.result[this.data.result.length-2] &&this.data.result.length >1) || (this.data.result.length == 1)) {
      var current = bobao[this.data.result[this.data.result.length-1]-1]
      current.play()
    }
  },

  submit:function(){
    this.setData({
      m : this.data.m+1
    })
    var m = this.data.m
    var data = {accXs:this.data.accXs.slice(-50), accYs:this.data.accYs.slice(-50), accZs:this.data.accZs.slice(-50), gyrXs:this.data.gyrXs.slice(-50), gyrYs:this.data.gyrYs.slice(-50), gyrZs:this.data.gyrZs.slice(-50)}
    this.data.all_data[m] = data        //每次上传的数据
    console.log(data)
    wx.request({
      url: 'https://www.action-recognition-wy.cn/', 
      data: { 
        data: JSON.stringify(data)
      },
      method: "POST",
      header: {
      'content-type': 'application/x-www-form-urlencoded',
      'chartset': 'utf-8'
      },
      success:res => {
        console.log('预测结果：', res.data, '成功')
        var number = parseInt(res.data)-1
        this.setData({ current_ation : action[number]})
        let result = this.data.result
        result.push(number+1) 
        this.setData({result:result})
      },
      fail:res =>{
        console.log(res,'失败')
      }
    })
  },

  Reset:function(){
    wx.redirectTo({
      url:'/pages/recognize/recognize'
    })
  },
  
  //对象转数组对象
  objToStrMap(obj){
      let arr=[ ];
      let arrObj=Object.entries(obj);
      arrObj.forEach(c =>{
      arr.push({
      keys:c[0],
      value:c[1]
      })
    })
    return arr;
  },
    

  clickVerify:function(){
    var that = this;
    if(that.data.literal == '开始检测'){
      innerAudioContext1.play()
      setTimeout(function () {
        that.setData({literal:'正在检测'})
        that.test();
      }, 1800)
    }
    if(that.data.literal == '显示详细信息'){
      that.setData({detail:true})
      // var data = {accXs:accXs, accYs:accYs, accZs:accZs, gyrXs:gyrXs, gyrYs:gyrYs, gyrZs:gyrZs}
      wx.showLoading({title: '计算中...',})
      wx.request({
        url: 'https://www.action-recognition-wy.cn/number', 
        data: { 
          data: JSON.stringify(that.data.all_data)    //传递30s全部数据
        },
        method: "POST",
        header: {
        'content-type': 'application/x-www-form-urlencoded',
        'chartset': 'utf-8'
        },
        success:res => {
          var arr = that.objToStrMap(res.data)
          that.setData({datas:arr})
          wx.hideLoading()
        },
        fail:res =>{
          console.log(res,'失败')
        }
      })
    }
   }
})