// pages/collect/collect.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    array1: ['iOS', 'Android'],
    elements: [{
      title: '徒手侧平举',
      name: '1',
      color: 'orange',
      pinyin:'hezhangtiao',
      shifan:'hezhang'
    },
    {
      title: '前后交叉小跑',
      name: '2',
      color: 'my3',
      pinyin:'jiaochapao',
      shifan:'jiaocha'
    },
    {
      title: '开合跳',
      name: '3',
      color: 'my2',
      pinyin:'kaihetiao',
      shifan:'kaihe'
    },
    {
      title: '半蹲',
      name: '4',
      color: 'my1',
      pinyin:'bandun',
      shifan:'ban'
    }]
  },

  bindPickerChange1: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      index1: e.detail.value
    })
    wx.setStorageSync('system', e.detail.value)
  },
})